import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Queue;

import bwapi.Position;
import bwapi.Unit;

public class QFlag {
	
	/**
	 * 셔틀
	 */
	private static Unit myUnit;
	/**
	 * 리버들
	 */
	private static List<Unit> myReaverQUnits = new ArrayList<Unit>();
	
	/**
	 * 현재상태
	 */
	private static QState crtState;
	
	
	/**
	 * 셔틀로 리버태우는 Count
	 */
	private static int loadFrameCount;
	
	/**
	 * 해당플래그는 쓰레드가 Q Table을 모두 다 읽은 시점이다
	 */
	private static boolean isFileReadComplete = false;
	
	/**
	 * 학습상태Flag
	 * STANDBY - 학습시작전 상태
	 * START - Action을 시작한상태
	 * END - Action이 끝난상태
	 * ING - Action을 시작 및 종료를 진행중인 상태
	 */
	private static String trainingStateFlag;
	
	/**
	 * 현재상태의 q값
	 * Action후 q값을 구할때 쓰인다
	 */
	private static double q;
	
	/**
	 * 선택된 다음Action
	 */
	private static QAction nextAction;
	
	/**
	 * 적군본진위치
	 */
	private static Position targetPosition;
	
	/**
	 * Move Action으로 이동하려는 Grid인덱스
	 */
	private static int movingTargetGrdIdx = 0;
	
	/**
	 * Attack Action으로 공격하려는 타겟유닛
	 */
	private static Unit targetUnit;
	/**
	 * 공격 타겟 인덱스
	 */
	private static int targetPositionIdx;
	
	/**
	 * 리버 스켈업 발사개수
	 */
	private static int scarabCount;
	
	/**
	 * 리버 스켈업 발사여부
	 */
	private static boolean isScarab;
	
	/**
	 * 초기설정완료여무
	 * 최초로딩시 Q Table을 쓰레드로 읽어 시간이 소요된다.
	 * 해당플래그는 쓰레드가 Q Table을 모두 다 읽은 시점이다
	 */
	private static boolean isInitComplete = false;

	public static int getScarabCount() {
		return scarabCount;
	}
	public static int getTargetPositionIdx() {
		return targetPositionIdx;
	}

	public static void setTargetPositionIdx(int targetPositionIdx) {
		QFlag.targetPositionIdx = targetPositionIdx;
	}
	public static void setScarabCount(int scarabCount) {
		QFlag.scarabCount = scarabCount;
	}

	public static void setInitComplete(boolean isInitComplete) {
		QFlag.isInitComplete = isInitComplete;
	}

	public static boolean isScarab() {
		return isScarab;
	}

	public static void setScarab(boolean isScarab) {
		QFlag.isScarab = isScarab;
	}

	public static boolean isInitComplete() {
		return isInitComplete;
	}

	public static List<Unit> getMyReaverQUnits() {
		return myReaverQUnits;
	}

	public static void addMyReaverQUnits(Unit unit) {
		QFlag.myReaverQUnits.add(unit);
	}

	public static QState getCrtState() {
		return crtState;
	}

	public static void setCrtState(QState crtState2) {
		QFlag.crtState = crtState2;
	}

	public static String getTrainingStateFlag() {
		return trainingStateFlag;
	}

	public static void setTrainingStateFlag(String trainingStateFlag) {
		QFlag.trainingStateFlag = trainingStateFlag;
	}

	public static double getQ() {
		return q;
	}

	public static void setQ(double q) {
		QFlag.q = q;
	}

	public static QAction getNextAction() {
		return nextAction;
	}

	public static void setNextAction(QAction nextAction) {
		QFlag.nextAction = nextAction;
	}

	public static int getLoadFrameCount() {
		return loadFrameCount;
	}

	public static void setLoadFrameCount(int loadFrameCount) {
		QFlag.loadFrameCount = loadFrameCount;
	}

	public static Position getTargetPosition() {
		return targetPosition;
	}

	public static void setTargetPosition(Position targetPosition) {
		QFlag.targetPosition = targetPosition;
	}
	
	public static Unit getMyUnit() {
		return myUnit;
	}

	public static int getMovingTargetGrdIdx() {
		return movingTargetGrdIdx;
	}

	public static void setMovingTargetGrdIdx(int movingTargetGrdIdx) {
		QFlag.movingTargetGrdIdx = movingTargetGrdIdx;
	}

	public static Unit getTargetUnit() {
		return targetUnit;
	}

	public static void setTargetUnit(Unit targetUnit) {
		QFlag.targetUnit = targetUnit;
	}

	public static void init() {
		
		// 최초 q러닝 플래그 스탠바이
		QFlag.setTrainingStateFlag(QConstants.StateFlagType.STANDBY);
		
		// 트레이닝 상태 대기로 셋팅
		QFlag.setTrainingStateFlag(QConstants.StateFlagType.STANDBY);
		
		// 공격할 유닛 및 액션 초기화
		QFlag.targetUnit = null;
		QFlag.setNextAction(null);
		
		// 셔틀 리버클리어
		QFlag.setMyUnit(null);
		QFlag.myReaverQUnits.clear();
		
		// 스캐랩 발사갯수 초기화
		QFlag.setScarabCount(0);
		
		// 파일 읽기 초기화
		QFlag.setFileReadComplete(false);
		
		// 공격지점 초기화
		QFlag.setTargetPositionIdx(0);
		
		// 초기화 완료
		QFlag.setInitComplete(true);
	}
	
	public static void destroyMyReaverQUnit(Unit unit) {
		for (Unit qUnit : myReaverQUnits) {
			if (unit.getID() == qUnit.getID()) {
				myReaverQUnits.remove(qUnit);
			}
		}
	}

	public static void setMyUnit(Unit unit) {
		myUnit = unit;
	}

	public static void destroyMyQUnit(Unit unit) {
		myUnit = null;
	}
	
	public static boolean isFileReadComplete() {
		return isFileReadComplete;
	}

	public static void setFileReadComplete(boolean isFileReadComplete) {
		QFlag.isFileReadComplete = isFileReadComplete;
	}
}