import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import bwapi.Game;
import bwapi.Player;
import bwapi.Unit;
import bwapi.UnitType;

public class QStateZ extends QState implements Serializable {
	
	private static final long serialVersionUID = -8339056876656299811L;
	
	/**
	 * Q유직의 시야 그리드 격자
	 */
	private List<Grid> grdList;
	
	/**
	 * 아군 Q유닛의 HP 총합
	 */
	private int myHitPoints;
	
	/**
	 * 아군 Q유닛의 scarabCount
	 */
	private int scarabCount;
	
	/**
	 * 공격해야할 적군의 유닛ID
	 */
	private int targetUnitId;
	
	/**
	 * 공격해야할 적군의 유닛 수
	 */
	private int targetUnitsCnt;
	
	/**
	 * Q유닛을 공격할 수 있는 범위에 있는 적군의 수
	 */
	private int eneAttackCnt;
	
	/**
	 * Q유닛 시야에 있는 적군의 수
	 */
	private int eneCount;
	
	/**
	 * Q유닛 시야에 있는 적군리스트
	 */
	private List<Integer> eneList;
	
	/**
	 * Q유닛을 공격할수 있는 범위에 있는 적군리스트
	 */
	private List<Integer> eneAttackList;
	
	/**
	 * Q유닛과 적군유닛들의 최단거리
	 */
	private int minDistance;
	
	public List<QStateZ.Grid> getGrdList() {
		return grdList;
	}

	public void setGrdList(List<Grid> grdList) {
		this.grdList = grdList;
	}

	public int getEneAttackCnt() {
		return eneAttackCnt;
	}

	public void setEneAttackCnt(int eneAttackCnt) {
		this.eneAttackCnt = eneAttackCnt;
	}

	public int getEneCount() {
		return eneCount;
	}

	public void setEneCount(int eneCount) {
		this.eneCount = eneCount;
	}

	public int getTargetUnitId() {
		return targetUnitId;
	}

	public void setTargetUnitId(int unitId) {
		this.targetUnitId = unitId;
	}

	public int getTargetUnitsCnt() {
		return targetUnitsCnt;
	}

	public void setTargetUnitsCnt(int targetUnitsCnt) {
		this.targetUnitsCnt = targetUnitsCnt;
	}

	public int getMinDistance() {
		return minDistance;
	}

	public void setMinDistance(int minDistance) {
		this.minDistance = minDistance;
	}

	public List<Integer> getEneList() {
		return eneList;
	}

	public void setEneList(List<Integer> eneList) {
		this.eneList = eneList;
	}
	
	public List<Integer> getEneAttackList() {
		return eneAttackList;
	}

	public void setEneAttackList(List<Integer> eneAttackList) {
		this.eneAttackList = eneAttackList;
	}

	class Grid implements Serializable {
		
		
		private static final long serialVersionUID = -6644891819898487279L;
		
		/**
		 * 그리드격자의 인덱스
		 */
		private int idx;
		
		/**
		 * 그리드 격자안의 적유닛 수
		 */
		private int eneCount;
		
		/**
		 * 이동해야할 X좌표
		 */
		private int movePositionX;
		
		/**
		 * 이동해야할 Y좌표
		 */
		private int movePositionY;
		
		public int getIdx() {
			return idx;
		}
		public void setIdx(int idx) {
			this.idx = idx;
		}
		public int getEneCount() {
			return eneCount;
		}
		public void setEneCount(int eneCount) {
			this.eneCount = eneCount;
		}
		public int getTargetUnit() {
			return targetUnitId;
		}
		public int getMovePositionX() {
			return movePositionX;
		}
		public void setMovePositionX(int movePositionX) {
			this.movePositionX = movePositionX;
		}
		public int getMovePositionY() {
			return movePositionY;
		}
		public void setMovePositionY(int movePositionY) {
			this.movePositionY = movePositionY;
		}
	}
	
	public QStateZ(Game game) {
		
		Player self = game.self();
		Player enemy = game.enemy();
		Unit myUnit = QFlag.getMyUnit();
		List<Integer> eneList = new ArrayList<Integer>();
		List<Integer> eneAttackList = new ArrayList<Integer>();
		
		int unitDistance = Integer.MAX_VALUE;
		int tmpUnitDistance = Integer.MAX_VALUE;
		
		eneAttackCnt = 0;
		eneCount = 0;
		targetUnitsCnt = 0;
		
		/*
		 * 아군 체력, cooldown의 합
		 */
		scarabCount = QFlag.getScarabCount();
		myHitPoints = 0;
		for (Unit mySelfUnit : self.getUnits()) {
			if (mySelfUnit.getType() == UnitType.Protoss_Reaver || mySelfUnit.getType() == UnitType.Protoss_Shuttle) {
				myHitPoints += mySelfUnit.getHitPoints();
			}
			// Scarab이 있다면 발사한 상태다..
			if (mySelfUnit.getType() == UnitType.Protoss_Scarab) {
				scarabCount++;
			}
		}
		QFlag.setScarabCount(scarabCount);
		
		this.setTargetUnitId(-1);
		for (Unit enemyUnit : enemy.getUnits()) {
			
			if (enemyUnit.getType() == UnitType.Zerg_Drone 
					|| enemyUnit.getType() == UnitType.Zerg_Zergling
					|| enemyUnit.getType() == UnitType.Zerg_Hydralisk
					//|| enemyUnit.getType() == UnitType.Zerg_Sunken_Colony
					|| enemyUnit.getType() == UnitType.Zerg_Spore_Colony
					) {
				// 시야에 보이지 않는 유닛은 스킵
				unitDistance = myUnit.getDistance(enemyUnit);
				if (unitDistance > QConstants.QUNIT_SINGHT_RANGE) {
					continue;
				}

				// 내가 공격가능한 거리에 있는 경우
				int attackRange = QConstants.QUNIT_GROUNDWEAPON_ATTCK_RANGE;
				//System.out.println("attackRange " + attackRange);
				//System.out.println("unitDistance " + unitDistance);
				if (attackRange >= unitDistance) {
					if (tmpUnitDistance > unitDistance) {
						tmpUnitDistance = unitDistance;
						this.setMinDistance(unitDistance);
						this.setTargetUnitId(enemyUnit.getID());
					}
					targetUnitsCnt++;
				}
				
				if (enemyUnit.getType() == UnitType.Zerg_Hydralisk || enemyUnit.getType() == UnitType.Zerg_Zergling) {
					eneCount++;
					eneList.add(enemyUnit.getID());
					
					// 상대방이 공격가능한 거리에 있는 경우
					if (UnitType.Zerg_Hydralisk.groundWeapon().maxRange() + 20 > unitDistance) {
						eneAttackCnt++;
						eneAttackList.add(enemyUnit.getID());
					}
				}
			}
		}
		
		this.setEneList(eneList);
		this.setEneAttackList(eneAttackList);
		
		grdList = new ArrayList<QStateZ.Grid>();
		int sightRange = QConstants.QUNIT_SINGHT_RANGE; // 224
		int divideCnt = QConstants.SINGHT_DIVIDE_CNT;
		int cellSize = sightRange / divideCnt;
		int cellSizeHalf = cellSize / 2;
		int cellCenterInitX = myUnit.getPosition().getX() - cellSize*divideCnt;
		int cellCenterInitY = myUnit.getPosition().getY() - cellSize*divideCnt;
		
		int cellCenterXL = cellCenterInitX;
		int cellCenterYD = cellCenterInitY;
		int idx = 0;
		for (int i = 0; i < divideCnt*2; i++) {
			int cellCenterYU = cellCenterYD + cellSize;
			for (int j = 0; j < divideCnt*2; j++) {
				int cellCenterXR = cellCenterXL + cellSize;

				int x = (cellCenterXL + cellCenterXR) / 2;
				int y = (cellCenterYD + cellCenterYU) / 2;
				idx++;
				
				QStateZ.Grid grd = new QStateZ.Grid();
				grd.setIdx(idx);
				
				// 그리드 격자 안에 적군을 update한다.
				int eneGrdCount = 0;
				
				int fx = x - cellSizeHalf;
				int tx = x + cellSizeHalf;
				int fy = y - cellSizeHalf;
				int ty = y + cellSizeHalf;
				
				for (Unit eneUnit : enemy.getUnits()) {
					if (eneUnit.getType() == UnitType.Zerg_Drone 
							|| eneUnit.getType() == UnitType.Zerg_Zergling
							|| eneUnit.getType() == UnitType.Zerg_Hydralisk
							|| eneUnit.getType() == UnitType.Zerg_Spore_Colony) {
						
						int eneX = eneUnit.getX();
						int eneY = eneUnit.getY();
						if (fx <= eneX && eneX <= tx) {
							if (fy <= eneY && eneY <= ty) {
								eneGrdCount++;
							}
						}
					}
				}
				grd.setEneCount(eneGrdCount);
				grd.setMovePositionX(x);
				grd.setMovePositionY(y);
				grdList.add(grd);
				cellCenterXL = cellCenterXL + cellSize;
			}
			cellCenterYD = cellCenterYD + cellSize;
			cellCenterXL = cellCenterInitX;
		}
	}

	/**
	 * 현재상태에서 진행가능한 Action을 리스트로 반환한다.
	 * @return
	 */
	public List<QAction> possibleActionsFromState() {
		List<QAction> actionList = new ArrayList<QAction>();
		// Move 액션
		for (Grid grid : this.getGrdList()) {
			QAction moveAction = new QAction();
			moveAction.setActionType(QConstants.ActionType.Move);
			moveAction.setMoveGrdIdx(grid.getIdx());
			// 갈수 없는 곳은 스킵처리
			if (QUtil.isUnreachablePosition(grid.getMovePositionX(), grid.getMovePositionY())) {
				continue;
			}
			moveAction.setMoveX(grid.getMovePositionX());
			moveAction.setMoveY(grid.getMovePositionY());
			actionList.add(moveAction);
		}
		
		// 공격 액션
		if (this.getTargetUnitsCnt() > 0 && QFlag.getMyUnit().canUnloadAll()) {
			QAction attackAction = new QAction();
			attackAction.setActionType(QConstants.ActionType.Attack);
			attackAction.setTargetId(this.getTargetUnitId());
			actionList.add(attackAction);
		}

		return actionList;
	}

	/**
	 * Train을 해야하는 상태인지 여부를 리턴한다.
	 * @return
	 */
	public boolean isTrainingState() {
		
		// 나를 공격할 수 있는 적군이 있는 경우
		if (this.getEneAttackCnt() > 0) {
			return true;
		}
		
		// 공격할 수 있는 적이 있는 경우
		if (this.getTargetUnitsCnt() > 0) {
			return true;	
		}
		return false;
	}
	
	@Override
	public boolean equals(Object o) {
		
		if (!(o instanceof QStateZ)) {
			return false;
		}
		
		QStateZ thisState = this;
		QStateZ otherState = (QStateZ) o;
		
		/*
		 * 적이 공격할 수 있는 유닛의 갯수
		 */
		int thisEneAttackCnt = thisState.getEneAttackCnt();
		int otherEneAttackCnt = otherState.getEneAttackCnt();
		if (thisEneAttackCnt == 0) {
			if (otherEneAttackCnt > 0) {
				return false;
			}
		}
		if (otherEneAttackCnt == 0) {
			if (thisEneAttackCnt > 0) {
				return false;
			}
		}
		
		/*
		 * 공격할 수 있는 히드라수
		 */
		int thisEneTagetCnt = thisState.getTargetUnitsCnt();
		int otherEneTagetCnt = otherState.getTargetUnitsCnt();
		if (thisEneTagetCnt < 4 && otherEneTagetCnt < 4) {
			if (thisEneTagetCnt != otherEneTagetCnt) {
				return false;
			}
		}
		
		/*
		 * 그리드 격자내의 유닛정보
		 */
		for (int i = 0; i < thisState.getGrdList().size(); i++) {
			
			Grid thisGid = thisState.getGrdList().get(i);
			Grid otherGid = otherState.getGrdList().get(i);
			
			int thisGrdEneCount = thisGid.getEneCount();
			int otherGrdEneCount = otherGid.getEneCount();
			
			/*
			 * 적군의 수
			 */
			if (thisGrdEneCount == 0) {
				if (otherGrdEneCount > 0) {
					return false;
				}
			}
			if (otherGrdEneCount == 0) {
				if (thisGrdEneCount > 0) {
					return false;
				}
			}
		}
        return true;
	}
	
	@Override
	public int getMinAttackUnitGrdIdx(Object grdListObj) {
		int enemyCnt = Integer.MAX_VALUE;
		int retIdx = 0;
		
		List<Grid> grdList = (List<Grid>) grdListObj; 
		
		for (Grid grid : grdList) {
			// 갈수 없는 곳은 스킵처리
			if (QUtil.isUnreachablePosition(grid.getMovePositionX(), grid.getMovePositionY())) {
				continue;
			}
			int tmpEnemyCnt = grid.getEneCount();
			if (enemyCnt > tmpEnemyCnt) {
				enemyCnt = tmpEnemyCnt;
				retIdx = grid.getIdx();
			}
		}
		return retIdx;
	}

	@Override
	public QAction getMoveActionWidGrdIdx(int grdIdx) {
		QAction moveAction = new QAction();
		moveAction.setActionType(QConstants.ActionType.Move);
		moveAction.setMoveGrdIdx(grdIdx);
		moveAction.setMoveX(this.getGrdList().get(grdIdx-1).getMovePositionX());
		moveAction.setMoveY(this.getGrdList().get(grdIdx-1).getMovePositionY());
		return moveAction;
	}

	@Override
	public boolean isUnreachableArea(int idx) {
		int x = this.getGrdList().get(idx-1).getMovePositionX();
		int y = this.getGrdList().get(idx-1).getMovePositionY();
		// 도달하지 못하는 부분 패스
		if (QUtil.isUnreachablePosition(x, y)) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * 과거 Action(Max Q값으로 가져온 Action)에 대해 현재상태의 Action정보를 반영한다.
	 */
	@Override
	public QAction setAttackMaxQAction(QAction ret) {
		if (QConstants.ActionType.Attack.equals(ret.getActionType())) {
			ret.setTargetId(this.getTargetUnitId());
		} else if (QConstants.ActionType.Move.equals(ret.getActionType())) {
			ret.setMoveX(this.getGrdList().get(ret.getMoveGrdIdx()-1).getMovePositionX());
			ret.setMoveY(this.getGrdList().get(ret.getMoveGrdIdx()-1).getMovePositionY());
		}
		return ret;
	}

	@Override
	public int getScarabCount() {
		return scarabCount;
	}

	@Override
	public int getMyHitPoints() {
		return myHitPoints;
	}
}
